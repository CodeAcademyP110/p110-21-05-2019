﻿using System;
using System.Net.Mail;
using System.Text;
using PrimaryClasses;

namespace P110_ConsoleDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            
        }
    }

    class Person
    {
        private string _firstname;

        public string Firstname
        {
            get { return _firstname; }
            set {
                if(value.Trim().Length >= 3)
                {
                    _firstname = value;
                    return;
                }
                throw new ArgumentException("Firstname should be more than 2 charachters.");
            }
        }

        public string Lastname { get; set; }

        private string _password;

        public string Password
        {
            get { return _password; }
        }

        public bool CheckPassword(string password)
        {
            return "123" + password + "@!#" == Password;
        }

        #region Encapsulation Manual way
        //private string _email;

        //public string GetEmail() => _email;

        //public void SetEmail(string email)
        //{
        //    try
        //    {
        //        MailAddress mailAddress = new MailAddress(email);
        //        _email = email;
        //    }   
        //    catch
        //    {
        //        throw new ArgumentException("Email is not valid");
        //    }
        //}
        #endregion
    }

    class Engineer : Person
    {
        public void ChangePassword()
        {
            Password = "sam";
        }
    }

    #region Class modifiers
    //public abstract class Animal
    //{
    //    public abstract void Eat();

    //    public virtual void Run()
    //    {
    //        Console.WriteLine("I am running");
    //    }
    //}

    //public abstract class Fliers : Animal
    //{
    //    public abstract void Fly();
    //}

    //public abstract class Reptiles : Animal { }

    //public class Hen : Fliers
    //{
    //    public override void Eat()
    //    {
    //        Console.WriteLine("I am eating as Hen");
    //    }

    //    public override void Fly()
    //    {
    //        Console.WriteLine("I am flying as Hen");
    //    }

    //    public override void Run()
    //    {
    //        Console.WriteLine("I am running as Hen");
    //    }
    //}

    //public class Snake : Reptiles
    //{
    //    public override void Eat()
    //    {
    //        Console.WriteLine("I am eating as snake");
    //    }
    //}

    //public sealed class Phyton : Snake
    //{
    //}
    #endregion

}

