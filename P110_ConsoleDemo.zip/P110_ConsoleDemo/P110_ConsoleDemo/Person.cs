﻿namespace P110_ConsoleDemo
{
    public abstract class Human
    {
        public string Firstname;
        public string Lastname;

        public Human() {}

        public Human(string firstname)
        {
            Firstname = firstname;
        }

        public Human(string firstname, string lastname) : this(firstname)
        {
            Lastname = lastname;
        }
    }

    public class Man : Human
    {
        public int BeardLength;
    }

    public class Woman : Human
    {
        public int HairLength;
    }
}

